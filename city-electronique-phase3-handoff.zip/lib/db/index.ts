import { drizzle } from 'drizzle-orm/node-postgres';
import { Pool } from 'pg';
import * as schema from './schema';
import { appConfig } from '../config/store';

declare global {
  var __cityPgPool: Pool | undefined;
}

function createPool(): Pool {
  return new Pool({
    connectionString: appConfig.databaseUrl,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
  });
}

export const pool = globalThis.__cityPgPool ?? createPool();

if (process.env.NODE_ENV !== 'production') {
  globalThis.__cityPgPool = pool;
}

export const db = drizzle(pool, { schema });
