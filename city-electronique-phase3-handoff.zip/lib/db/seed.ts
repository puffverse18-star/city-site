import { db, pool } from './index';
import * as schema from './schema';
import bcrypt from 'bcryptjs';

export async function runSeed() {
  console.log('🌱 Starting deterministic development seed for CITY Électronique...');

  // 1. Create Superadmin
  const passwordHash = await bcrypt.hash('AdminCity2026!', 12);
  const [admin] = await db
    .insert(schema.adminUsers)
    .values({
      email: 'admin@city-electronique.ma',
      fullName: 'Directeur Technique CITY',
      passwordHash,
      role: 'superadmin',
    })
    .onConflictDoNothing()
    .returning();

  console.log('✓ Admin user initialized:', admin ? admin.email : 'already exists');

  // 2. Inventory Locations
  const [showroom] = await db
    .insert(schema.inventorySources)
    .values({
      code: 'casa_maarif_showroom',
      name: 'Showroom Casablanca Maârif',
      type: 'physical_store',
      isOnlineFulfillment: true,
    })
    .onConflictDoNothing()
    .returning();

  const [depot] = await db
    .insert(schema.inventorySources)
    .values({
      code: 'ain_sebaa_depot',
      name: 'Dépôt Central Aïn Sebaâ',
      type: 'central_warehouse',
      isOnlineFulfillment: true,
    })
    .onConflictDoNothing()
    .returning();

  console.log('✓ Inventory locations seeded (Showroom & Dépôt)');

  // 3. Catalog Sources
  const [supplierA] = await db
    .insert(schema.catalogSources)
    .values({
      code: 'fournisseur_officiel_tech',
      name: 'Distributeur Officiel High-Tech Maroc',
      type: 'csv',
    })
    .onConflictDoNothing()
    .returning();

  const [supplierB] = await db
    .insert(schema.catalogSources)
    .values({
      code: 'importateur_audio_direct',
      name: 'Importateur Audio Direct Casablanca',
      type: 'json',
    })
    .onConflictDoNothing()
    .returning();

  console.log('✓ Catalog sources initialized');

  // 4. Brands & Categories
  const [sonyBrand] = await db
    .insert(schema.brands)
    .values({
      name: 'Sony',
      slug: 'sony',
      description: 'Ingénierie acoustique et imagerie professionnelle japonaise.',
      isFeatured: true,
    })
    .onConflictDoNothing()
    .returning();

  const [appleBrand] = await db
    .insert(schema.brands)
    .values({
      name: 'Apple',
      slug: 'apple',
      description: 'Écosystème technologique haute performance.',
      isFeatured: true,
    })
    .onConflictDoNothing()
    .returning();

  const [audioCat] = await db
    .insert(schema.categories)
    .values({
      name: 'Audio Haute Fidélité',
      slug: 'audio-haute-fidelite',
      description: 'Casques à réduction de bruit et écouteurs audiophiles.',
      isFeatured: true,
    })
    .onConflictDoNothing()
    .returning();

  const [smartphonesCat] = await db
    .insert(schema.categories)
    .values({
      name: 'Smartphones & Mobilité',
      slug: 'smartphones-mobilite',
      description: 'Téléphones intelligents de référence.',
      isFeatured: true,
    })
    .onConflictDoNothing()
    .returning();

  console.log('✓ Brands & Categories initialized');

  // 5. SAMPLE PRODUCT 1: With Multiple Variants (Apple iPhone 15 Pro)
  if (appleBrand && smartphonesCat && showroom && depot) {
    const [iphoneProduct] = await db
      .insert(schema.products)
      .values({
        slug: 'apple-iphone-15-pro',
        brandId: appleBrand.id,
        categoryId: smartphonesCat.id,
        derivedName: 'Apple iPhone 15 Pro',
        overrideName: 'Apple iPhone 15 Pro (Titane Naturel / Noir)',
        isNameOverridden: true,
        derivedDescription: 'Châssis en titane aérospatial, puce A17 Pro.',
        derivedPrice: '12990.00',
        overridePrice: '12490.00', // Surchargé manuellement en DH
        isPriceOverridden: true,
        isPublished: true,
        isFeatured: true,
        availabilityStatus: 'in_stock',
        seoTitle: 'Apple iPhone 15 Pro au Maroc | CITY Électronique',
        seoDescription: 'Achetez votre iPhone 15 Pro en titane au meilleur prix au Maroc avec livraison express et garantie.',
      })
      .onConflictDoNothing()
      .returning();

    if (iphoneProduct) {
      // Variant 1: 128GB Noir Sidéral
      const [var1] = await db
        .insert(schema.productVariants)
        .values({
          productId: iphoneProduct.id,
          sku: 'IPH15P-128-BLK',
          barcode: '0195949012345',
          name: '128 Go / Titane Noir',
          isDefaultVariant: true,
          attributes: { capacity: '128GB', color: 'Titane Noir' },
          derivedPrice: '12490.00',
          specifications: { ecran: '6.1 pouces Super Retina XDR', processeur: 'Puce A17 Pro', connectique: 'USB-C' },
        })
        .returning();

      // Variant 2: 256GB Titane Naturel
      const [var2] = await db
        .insert(schema.productVariants)
        .values({
          productId: iphoneProduct.id,
          sku: 'IPH15P-256-NAT',
          barcode: '0195949012346',
          name: '256 Go / Titane Naturel',
          isDefaultVariant: false,
          attributes: { capacity: '256GB', color: 'Titane Naturel' },
          derivedPrice: '13990.00',
          specifications: { ecran: '6.1 pouces Super Retina XDR', processeur: 'Puce A17 Pro', connectique: 'USB-C' },
        })
        .returning();

      // Inventory for Variants
      if (var1) {
        await db.insert(schema.inventoryItems).values({
          variantId: var1.id,
          inventorySourceId: showroom.id,
          physicalQuantity: 4,
          reservedQuantity: 1, // Available = 3
        });
        await db.insert(schema.inventoryItems).values({
          variantId: var1.id,
          inventorySourceId: depot.id,
          physicalQuantity: 10,
          reservedQuantity: 0, // Available = 10
        });
      }

      if (var2) {
        await db.insert(schema.inventoryItems).values({
          variantId: var2.id,
          inventorySourceId: showroom.id,
          physicalQuantity: 2,
          reservedQuantity: 0,
        });
      }

      console.log('✓ Product with variants seeded (iPhone 15 Pro)');
    }
  }

  // 6. SAMPLE PRODUCT 2: Without Variants (receives default variant)
  if (sonyBrand && audioCat && showroom) {
    const [sonyProduct] = await db
      .insert(schema.products)
      .values({
        slug: 'sony-wh-1000xm5-noir',
        brandId: sonyBrand.id,
        categoryId: audioCat.id,
        derivedName: 'Sony WH-1000XM5 Casque Sans Fil',
        derivedDescription: 'Casque circum-aural avec réduction de bruit active d’exception.',
        derivedPrice: '3890.00',
        isPriceOverridden: false, // Pas de surcharge : prix source actif
        isPublished: true,
        isFeatured: true,
        availabilityStatus: 'in_stock',
        seoTitle: 'Casque Sony WH-1000XM5 au Maroc | CITY Électronique',
        seoDescription: 'Casque nomade Sony WH-1000XM5 avec réduction de bruit active au Maroc.',
      })
      .onConflictDoNothing()
      .returning();

    if (sonyProduct) {
      const [defaultVar] = await db
        .insert(schema.productVariants)
        .values({
          productId: sonyProduct.id,
          sku: 'SNY-WHXM5-BLK',
          barcode: '4548736130310',
          name: 'Édition Standard Noir',
          isDefaultVariant: true, // Default variant as required
          attributes: { color: 'Noir' },
          derivedPrice: '3890.00',
          specifications: { autonomie: '30 heures', reduction_bruit: 'Processeur V1 + QN1 HD', poids: '250 g' },
        })
        .returning();

      if (defaultVar) {
        await db.insert(schema.inventoryItems).values({
          variantId: defaultVar.id,
          inventorySourceId: showroom.id,
          physicalQuantity: 6,
          reservedQuantity: 2, // Available = 4
        });
      }

      console.log('✓ Product without variants seeded with default variant (Sony WH-1000XM5)');
    }
  }

  console.log('✨ Seed completed successfully.');
}

// Allow direct execution via CLI
if (require.main === module) {
  runSeed()
    .then(async () => {
      await pool.end();
      process.exit(0);
    })
    .catch(async (err) => {
      console.error('❌ Seed execution failed:', err);
      await pool.end();
      process.exit(1);
    });
}
